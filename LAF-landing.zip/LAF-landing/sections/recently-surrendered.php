<?php /* ============================================================
   SECTION: RECENTLY SURRENDERED
   FILE: sections/recently-surrendered.php
   ✅ SAFE TO EDIT — only this file
   ============================================================ */ ?>

<style>
  .laf-recently-surrendered {
    background: var(--laf-gray-bg, #f5f6fa);
    padding: 80px 0;
  }
  .laf-item-card {
    background: #fff;
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 4px 24px rgba(75,94,170,0.09);
    transition: transform 0.20s ease, box-shadow 0.20s ease;
    height: 100%;
  }
  .laf-item-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 32px rgba(75,94,170,0.18);
  }
  .laf-item-thumb {
    height: 110px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 3.2rem;
  }
  .laf-item-card .item-name {
    font-size: 0.85rem;
    font-weight: 700;
    margin-bottom: 2px;
  }
  .laf-item-card .item-loc {
    font-size: 0.75rem;
    color: #8896c8;
  }

  /* Status badges */
  .laf-badge {
    font-size: 0.68rem;
    font-weight: 700;
    padding: 3px 10px;
    border-radius: 50px;
    display: inline-block;
    margin-bottom: 6px;
  }
  .laf-badge-found   { background: #d4edda; color: #155724; }
  .laf-badge-claimed { background: #fff3cd; color: #856404; }
  .laf-badge-new     { background: #cce5ff; color: #004085; }
  .laf-badge-urgent  { background: #f8d7da; color: #721c24; }

  .laf-view-all {
    background: var(--laf-primary, #4B5EAA);
    color: #fff;
    border: none;
    font-weight: 700;
    padding: 13px 32px;
    border-radius: 10px;
    font-size: 0.95rem;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    transition: transform 0.18s ease, box-shadow 0.18s ease, background 0.18s ease;
  }
  .laf-view-all:hover {
    background: #6272c4;
    color: #fff;
    transform: translateY(-3px);
    box-shadow: 0 8px 24px rgba(75,94,170,0.28);
  }

  @media (max-width: 767px) {
    .laf-recently-surrendered { padding: 50px 0; }
  }
</style>

<section class="laf-recently-surrendered" id="laf-recently-surrendered">
  <div class="container-xxl app-container">

    <div class="text-center mb-12" data-aos="fade-up">
      <span class="laf-label">Just Dropped Off</span>
      <h2 class="mt-2" style="font-size:clamp(1.8rem,4vw,2.6rem); font-weight:900; font-style:italic; color:#1a1f36;">
        Recently Surrendered
      </h2>
      <p class="text-muted fs-6 mt-2">These items are currently waiting to be claimed. Log in to see your lost and found items.</p>
    </div>

    <div class="row g-4 mb-10">

      <div class="col-6 col-md-4 col-lg-2" data-aos="fade-up" data-aos-delay="0">
        <div class="laf-item-card">
          <div class="laf-item-thumb" style="background:#e8f4fd;">🥤</div>
          <div class="p-3">
            <span class="laf-badge laf-badge-found">Found</span>
            <p class="item-name">Blue Tumbler</p>
            <p class="item-loc">Building A, 3F</p>
          </div>
        </div>
      </div>

      <div class="col-6 col-md-4 col-lg-2" data-aos="fade-up" data-aos-delay="60">
        <div class="laf-item-card">
          <div class="laf-item-thumb" style="background:#fdf3e8;">🎧</div>
          <div class="p-3">
            <span class="laf-badge laf-badge-new">New</span>
            <p class="item-name">Wireless Headphones</p>
            <p class="item-loc">Library, GF</p>
          </div>
        </div>
      </div>

      <div class="col-6 col-md-4 col-lg-2" data-aos="fade-up" data-aos-delay="120">
        <div class="laf-item-card">
          <div class="laf-item-thumb" style="background:#f0fdf4;">📓</div>
          <div class="p-3">
            <span class="laf-badge laf-badge-found">Found</span>
            <p class="item-name">Spiral Notebook</p>
            <p class="item-loc">Canteen</p>
          </div>
        </div>
      </div>

      <div class="col-6 col-md-4 col-lg-2" data-aos="fade-up" data-aos-delay="180">
        <div class="laf-item-card">
          <div class="laf-item-thumb" style="background:#fef9e7;">👜</div>
          <div class="p-3">
            <span class="laf-badge laf-badge-urgent">Urgent</span>
            <p class="item-name">Brown Leather Bag</p>
            <p class="item-loc">Lobby</p>
          </div>
        </div>
      </div>

      <div class="col-6 col-md-4 col-lg-2" data-aos="fade-up" data-aos-delay="240">
        <div class="laf-item-card">
          <div class="laf-item-thumb" style="background:#fdf3f3;">✏️</div>
          <div class="p-3">
            <span class="laf-badge laf-badge-claimed">Claimed</span>
            <p class="item-name">Pencil Case</p>
            <p class="item-loc">Room 204</p>
          </div>
        </div>
      </div>

      <div class="col-6 col-md-4 col-lg-2" data-aos="fade-up" data-aos-delay="300">
        <div class="laf-item-card">
          <div class="laf-item-thumb" style="background:#f0f4ff;">🔑</div>
          <div class="p-3">
            <span class="laf-badge laf-badge-new">New</span>
            <p class="item-name">Key with Lanyard</p>
            <p class="item-loc">Gym Entrance</p>
          </div>
        </div>
      </div>

    </div>

    <div class="text-center" data-aos="fade-up" data-aos-delay="80">
      <a href="#" class="laf-view-all">
        View All Items <i class="bi bi-arrow-right"></i>
      </a>
    </div>

  </div>
</section>
