<?php /* ============================================================
   SECTION: BUILT FOR CAMPUS LIFE
   FILE: sections/built.php
   ✅ SAFE TO EDIT — only this file
   ============================================================ */ ?>

<style>
  .laf-built {
    background: var(--laf-navy, #1e2a4a);
    padding: 80px 0;
    position: relative;
    overflow: hidden;
  }
  .laf-built::before {
    content: '';
    position: absolute;
    top: -100px; right: -100px;
    width: 500px; height: 500px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(255,255,255,0.04) 0%, transparent 70%);
    pointer-events: none;
  }
  .laf-built::after {
    content: '';
    position: absolute;
    bottom: -80px; left: -80px;
    width: 360px; height: 360px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(245,166,35,0.05) 0%, transparent 70%);
    pointer-events: none;
  }

  .laf-feature-card {
    background: rgba(255,255,255,0.07);
    border: 1px solid rgba(255,255,255,0.10);
    border-radius: 16px;
    padding: 28px 24px;
    height: 100%;
    transition: transform 0.22s ease, background 0.22s ease, border-color 0.22s ease, box-shadow 0.22s ease;
  }
  .laf-feature-card:hover {
    transform: translateY(-6px);
    background: rgba(255,255,255,0.12);
    border-color: rgba(75,94,170,0.55);
    box-shadow: 0 14px 36px rgba(0,0,0,0.28);
  }
  .laf-feature-icon {
    width: 52px;
    height: 52px;
    border-radius: 12px;
    background: rgba(255,255,255,0.10);
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 16px;
  }
  .laf-feature-card h5 {
    color: #fff;
    font-weight: 700;
    margin-bottom: 8px;
  }
  .laf-feature-card p {
    color: rgba(255,255,255,0.60);
    font-size: 0.88rem;
    margin-bottom: 0;
    line-height: 1.65;
  }

  @media (max-width: 767px) {
    .laf-built { padding: 50px 0; }
  }
</style>

<section class="laf-built" id="laf-built">
  <div class="container-xxl app-container position-relative">

    <div class="text-center mb-14" data-aos="fade-up">
      <span class="laf-label" style="color: var(--laf-accent, #f5a623);">Built for Campus</span>
      <h2 class="laf-heading mt-2 text-white">
        Built for <em style="color:var(--laf-accent, #f5a623); font-style:italic;">Campus Life</em>
      </h2>
      <p class="mt-3 fs-6 mx-auto" style="color:rgba(255,255,255,0.60); max-width:500px;">
        Our platform is designed to help you find lost and found campus items and reunite students or staffs with their belongings.
      </p>
    </div>

    <div class="row g-5">

      <div class="col-12 col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="0">
        <div class="laf-feature-card">
          <div class="laf-feature-icon">
            <i class="bi bi-broadcast fs-4" style="color:#7fa8ff;"></i>
          </div>
          <h5>Live Item Feed</h5>
          <p>Browse all items found on campus in real time. Filter by category, deadline and location to find what's yours.</p>
        </div>
      </div>

      <div class="col-12 col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="80">
        <div class="laf-feature-card">
          <div class="laf-feature-icon">
            <i class="bi bi-camera fs-4" style="color:var(--laf-accent, #f5a623);"></i>
          </div>
          <h5>Photo Submissions</h5>
          <p>Anyone who finds something on campus can easily upload it using our simple submission form.</p>
        </div>
      </div>

      <div class="col-12 col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="160">
        <div class="laf-feature-card" style="border-color:rgba(245,166,35,0.28);">
          <div class="laf-feature-icon" style="background:rgba(245,166,35,0.15);">
            <i class="bi bi-star-fill fs-4" style="color:var(--laf-accent, #f5a623);"></i>
          </div>
          <h5>Featured Items</h5>
          <p>The most saved and wide collection of recently surrendered items from around campus.</p>
        </div>
      </div>

      <div class="col-12 col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="0">
        <div class="laf-feature-card">
          <div class="laf-feature-icon">
            <i class="bi bi-tags fs-4" style="color:#7fa8ff;"></i>
          </div>
          <h5>Category Tags</h5>
          <p>Items are sorted into categories like Electronics, Academics and Personal Essentials for faster finding.</p>
        </div>
      </div>

      <div class="col-12 col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="80">
        <div class="laf-feature-card">
          <div class="laf-feature-icon">
            <i class="bi bi-geo-alt-fill fs-4" style="color:#ff7f7f;"></i>
          </div>
          <h5>Location Enabling</h5>
          <p>Track where items were found so you can narrow down to the nearest location on campus.</p>
        </div>
      </div>

      <div class="col-12 col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="160">
        <div class="laf-feature-card">
          <div class="laf-feature-icon">
            <i class="bi bi-clock-history fs-4" style="color:#7fffd4;"></i>
          </div>
          <h5>Claim History</h5>
          <p>Retrieve all your claims and history, allowing you to track unclaimed items effectively.</p>
        </div>
      </div>

    </div>
  </div>
</section>
