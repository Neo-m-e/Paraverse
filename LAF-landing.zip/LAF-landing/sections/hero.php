<?php /* ============================================================
   SECTION: HERO
   FILE: sections/hero.php
   ✅ SAFE TO EDIT — only this file
   ============================================================ */ ?>

<!-- AOS Library (loaded once here, used by all sections) -->
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js" defer></script>

<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<style>
  /* ── Global: sans-serif only, everywhere ── */
  body, h1, h2, h3, h4, h5, h6, p, span, a, li, button, input, label {
    font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif !important;
  }

  /* ── CSS Variables ── */
  :root {
    --laf-primary:       #4B5EAA;
    --laf-primary-light: #6272c4;
    --laf-navy:          #1e2a4a;
    --laf-accent:        #f5a623;
    --laf-gray-bg:       #f5f6fa;
    --laf-card-shadow:   0 4px 24px rgba(75,94,170,0.10);
    --laf-font:          'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
  }

  /* ── Shared section label ── */
  .laf-label {
    font-size: 0.72rem;
    font-weight: 700;
    letter-spacing: 0.14em;
    text-transform: uppercase;
    color: var(--laf-primary);
  }

  /* ── Shared section heading ── */
  .laf-heading {
    font-size: clamp(1.6rem, 3.5vw, 2.3rem);
    font-weight: 900;
    color: #1a1f36;
  }

  /* ── Shared buttons ── */
  .laf-btn-primary {
    background: var(--laf-primary);
    border: none;
    color: #fff;
    font-weight: 700;
    padding: 14px 30px;
    border-radius: 10px;
    font-size: 0.97rem;
    transition: transform 0.18s ease, box-shadow 0.18s ease, background 0.18s ease;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
  }
  .laf-btn-primary:hover {
    background: var(--laf-primary-light);
    color: #fff;
    transform: translateY(-3px);
    box-shadow: 0 8px 24px rgba(75,94,170,0.30);
  }
  .laf-btn-outline {
    background: #fff;
    border: 2px solid #dde2f0;
    color: #3a4060;
    font-weight: 700;
    padding: 12px 30px;
    border-radius: 10px;
    font-size: 0.97rem;
    transition: transform 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
  }
  .laf-btn-outline:hover {
    border-color: var(--laf-primary);
    color: var(--laf-primary);
    transform: translateY(-3px);
    box-shadow: 0 6px 18px rgba(75,94,170,0.12);
  }

  /* ── Hero ── */
  .laf-hero {
    background: var(--laf-gray-bg);
    padding: 80px 0 60px;
    position: relative;
    overflow: hidden;
  }
  .laf-hero::before {
    content: '';
    position: absolute;
    top: -120px; right: -120px;
    width: 480px; height: 480px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(75,94,170,0.10) 0%, transparent 70%);
    pointer-events: none;
  }
  .laf-hero::after {
    content: '';
    position: absolute;
    bottom: -80px; left: -80px;
    width: 320px; height: 320px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(245,166,35,0.08) 0%, transparent 70%);
    pointer-events: none;
  }
  .laf-hero h1 {
    font-size: clamp(2.2rem, 5vw, 3.4rem);
    font-weight: 900;
    line-height: 1.15;
    color: #1a1f36;
  }
  .laf-hero h1 .accent {
    color: var(--laf-primary);
    font-style: italic;
  }
  .laf-hero .hero-desc {
    font-size: 1.05rem;
    color: #5a607a;
    line-height: 1.75;
    max-width: 480px;
  }

  /* ── 3D Placeholder ── */
  .hero-3d-placeholder {
    width: 100%;
    max-width: 460px;
    min-height: 340px;
    border-radius: 24px;
    background: linear-gradient(135deg, #e8ecf8 0%, #d8dff5 100%);
    border: 2.5px dashed #b0bde8;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    color: #8896c8;
    font-size: 0.9rem;
    font-weight: 600;
    animation: laf-float 4s ease-in-out infinite;
    position: relative;
    overflow: hidden;
  }
  .hero-3d-placeholder::before {
    content: '';
    position: absolute;
    inset: 0;
    background: repeating-linear-gradient(
      45deg,
      transparent, transparent 18px,
      rgba(75,94,170,0.03) 18px, rgba(75,94,170,0.03) 36px
    );
  }
  @keyframes laf-float {
    0%, 100% { transform: translateY(0); }
    50%       { transform: translateY(-12px); }
  }

  @media (max-width: 767px) {
    .laf-hero { padding: 50px 0 40px; }
    .hero-3d-placeholder { min-height: 220px; }
  }
</style>

<section class="laf-hero" id="laf-hero">
  <div class="container-xxl app-container">
    <div class="row align-items-center g-8">

      <!-- Left: Text -->
      <div class="col-12 col-lg-6" data-aos="fade-right" data-aos-duration="700">
        <h1>
          Lost Something?<br>
          <span class="accent">We'll Find It.</span><br>
          Together.
        </h1>
        <p class="hero-desc mt-5 mb-8">
          Join the campus-wide movement to help students and staff quickly locate, report, and recover lost belongings. Our intelligent platform connects finders with owners in record time.
        </p>
        <div class="d-flex flex-wrap gap-3">
          <a href="#" class="laf-btn-primary">
            Start Your Journey <i class="bi bi-arrow-right"></i>
          </a>
          <a href="#laf-getting-started" class="laf-btn-outline scroll-laf">
            See How It Works
          </a>
        </div>
      </div>

      <!-- Right: 3D Image Placeholder -->
      <div class="col-12 col-lg-6 d-flex justify-content-center mt-6 mt-lg-0"
           data-aos="fade-left" data-aos-duration="700" data-aos-delay="150">
        <!--
        ╔══════════════════════════════════════════╗
        ║  3D IMAGE PLACEHOLDER                    ║
        ║  Replace this div with your 3D asset     ║
        ╚══════════════════════════════════════════╝
        -->
        <div class="hero-3d-placeholder">
          <i class="bi bi-box-seam" style="font-size:5rem; opacity:0.22; color:var(--laf-primary);"></i>
          <span class="mt-3" style="opacity:0.40;">[ 3D Image — replace this div ]</span>
        </div>
        <!-- END 3D PLACEHOLDER -->
      </div>

    </div>
  </div>
</section>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    // Init AOS once for the whole page
    if (typeof AOS !== 'undefined') AOS.init({ once: true, duration: 650, offset: 60 });

    // Smooth scroll for hero CTA
    document.querySelectorAll('.scroll-laf').forEach(function (el) {
      el.addEventListener('click', function (e) {
        var target = document.querySelector(this.getAttribute('href'));
        if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth' }); }
      });
    });
  });
</script>
