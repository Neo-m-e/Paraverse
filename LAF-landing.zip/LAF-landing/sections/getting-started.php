<?php /* ============================================================
   SECTION: GETTING STARTED
   FILE: sections/getting-started.php
   ✅ SAFE TO EDIT — only this file
   ============================================================ */ ?>

<style>
  .laf-getting-started {
    background: #fff;
    padding: 80px 0;
  }
  .laf-step-icon {
    width: 72px;
    height: 72px;
    border-radius: 50%;
    background: #eef0fa;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    transition: transform 0.20s ease, background 0.20s ease;
  }
  .laf-step-icon:hover {
    background: var(--laf-primary, #4B5EAA);
    transform: scale(1.10);
  }
  .laf-step-icon:hover i {
    color: #fff !important;
  }
  @media (max-width: 767px) {
    .laf-getting-started { padding: 50px 0; }
  }
</style>

<section class="laf-getting-started" id="laf-getting-started">
  <div class="container-xxl app-container">

    <div class="text-center mb-14" data-aos="fade-up">
      <span class="laf-label">First Things First</span>
      <h2 class="laf-heading mt-2">Getting started is easy</h2>
    </div>

    <div class="row g-8 justify-content-center text-center">

      <div class="col-12 col-md-4" data-aos="fade-up" data-aos-delay="0">
        <div class="laf-step-icon">
          <i class="bi bi-person-plus fs-3" style="color:var(--laf-primary, #4B5EAA);"></i>
        </div>
        <h5 class="fw-bold mb-2">Create your account</h5>
        <p class="text-muted fs-6 mb-0">Sign up using your university email to begin your lost and found journey.</p>
      </div>

      <div class="col-12 col-md-4" data-aos="fade-up" data-aos-delay="100">
        <div class="laf-step-icon">
          <i class="bi bi-search fs-3" style="color:var(--laf-primary, #4B5EAA);"></i>
        </div>
        <h5 class="fw-bold mb-2">Search or report</h5>
        <p class="text-muted fs-6 mb-0">Use our platform to search for lost items or to report something you found on campus.</p>
      </div>

      <div class="col-12 col-md-4" data-aos="fade-up" data-aos-delay="200">
        <div class="laf-step-icon">
          <i class="bi bi-people fs-3" style="color:var(--laf-primary, #4B5EAA);"></i>
        </div>
        <h5 class="fw-bold mb-2">Recover or reunite</h5>
        <p class="text-muted fs-6 mb-0">The system notifies and connects owners so items can be safely returned to them.</p>
      </div>

    </div>
  </div>
</section>
