<?php /* ============================================================
   SECTION: ITEM CATEGORIES
   FILE: sections/item-categories.php
   ✅ SAFE TO EDIT — only this file
   ============================================================ */ ?>

<style>
  .laf-item-categories {
    background: #fff;
    padding: 80px 0;
  }
  .laf-cat-pill {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    background: #f0f2fb;
    border-radius: 50px;
    padding: 10px 20px;
    font-size: 0.88rem;
    font-weight: 600;
    color: #3a4060;
    border: 1.5px solid transparent;
    text-decoration: none;
    transition: background 0.18s ease, color 0.18s ease, transform 0.18s ease, border-color 0.18s ease;
  }
  .laf-cat-pill:hover {
    background: var(--laf-primary, #4B5EAA);
    color: #fff;
    border-color: var(--laf-primary, #4B5EAA);
    transform: translateY(-2px);
  }
  .laf-live-tag {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: #fff3cd;
    border: 1.5px solid #ffc107;
    border-radius: 50px;
    padding: 5px 14px;
    font-size: 0.78rem;
    font-weight: 700;
    color: #856404;
    animation: laf-pulse 2s ease-in-out infinite;
  }
  .laf-live-tag .dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: #ffc107;
    display: inline-block;
  }
  @keyframes laf-pulse {
    0%, 100% { opacity: 1; }
    50%       { opacity: 0.65; }
  }
  @media (max-width: 767px) {
    .laf-item-categories { padding: 50px 0; }
  }
</style>

<section class="laf-item-categories" id="laf-item-categories">
  <div class="container-xxl app-container">

    <div class="text-center mb-10" data-aos="fade-up">
      <span class="laf-label">Built My Items</span>
      <h2 class="mt-2" style="font-size:clamp(1.8rem,4vw,2.6rem); font-weight:900; color:#1a1f36;">
        <em style="font-style:italic; color:var(--laf-primary, #4B5EAA);">Item</em> Categories
      </h2>
      <p class="text-muted fs-6 mt-2 mx-auto" style="max-width:520px;">
        From everyday essentials to academic tools — if it's lost on campus, it belongs here.
      </p>
      <div class="mt-4">
        <span class="laf-live-tag">
          <span class="dot"></span>
          email straight under live updates
        </span>
      </div>
    </div>

    <div class="d-flex flex-wrap justify-content-center gap-3" data-aos="fade-up" data-aos-delay="80">
      <a href="#" class="laf-cat-pill">🎒 Bags</a>
      <a href="#" class="laf-cat-pill">📚 Academic</a>
      <a href="#" class="laf-cat-pill">💻 Electronics</a>
      <a href="#" class="laf-cat-pill">📄 Documents</a>
      <a href="#" class="laf-cat-pill">🧴 Personal Essentials</a>
      <a href="#" class="laf-cat-pill">🎀 Accessories</a>
      <a href="#" class="laf-cat-pill">👕 Clothing</a>
      <a href="#" class="laf-cat-pill">👛 Wallets</a>
      <a href="#" class="laf-cat-pill">🪪 ID &amp; Cards</a>
    </div>

  </div>
</section>
