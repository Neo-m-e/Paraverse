<?php /* ============================================================
   SECTION: HOW TO TURN IN FOUND ITEMS
   FILE: sections/how-to-turn-in.php
   ✅ SAFE TO EDIT — only this file
   ============================================================ */ ?>

<style>
  .laf-how-to-turn-in {
    background: #fff;
    padding: 80px 0;
  }
  .laf-surrender-illustration {
    background: linear-gradient(135deg, #eef0fa 0%, #dfe4f5 100%);
    border-radius: 20px;
    min-height: 340px;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px dashed #c5cce8;
  }
  .laf-step-num {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    background: var(--laf-primary, #4B5EAA);
    color: #fff;
    font-weight: 800;
    font-size: 1rem;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    box-shadow: 0 4px 14px rgba(75,94,170,0.30);
  }
  @media (max-width: 767px) {
    .laf-how-to-turn-in { padding: 50px 0; }
    .laf-surrender-illustration { min-height: 200px; }
  }
</style>

<section class="laf-how-to-turn-in" id="laf-how-to-turn-in">
  <div class="container-xxl app-container">
    <div class="row align-items-center g-10">

      <!-- Illustration -->
      <div class="col-12 col-lg-5 order-2 order-lg-1" data-aos="fade-right">
        <div class="laf-surrender-illustration">
          <div class="text-center p-10">
            <i class="bi bi-person-check" style="font-size:6rem; opacity:0.18; color:var(--laf-primary, #4B5EAA);"></i>
            <p class="mt-3 fs-7 fw-semibold" style="color:#8896c8; opacity:0.6; font-size:0.8rem;">[ Illustration Placeholder ]</p>
          </div>
        </div>
      </div>

      <!-- Steps -->
      <div class="col-12 col-lg-7 order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
        <span class="laf-label">Surrender Process</span>
        <h2 class="laf-heading mt-2 mb-4">How to turn in found items</h2>
        <p class="text-muted fs-6 mb-8">
          Found something on campus? Follow these simple steps to report the item so it's properly logged and returned to its rightful owner.
        </p>

        <div class="d-flex flex-column gap-6">

          <div class="d-flex align-items-start gap-4" data-aos="fade-up" data-aos-delay="0">
            <div class="laf-step-num">1</div>
            <div>
              <h6 class="fw-bold mb-1">Secure Item</h6>
              <p class="text-muted fs-6 mb-0">Bring the item to Office 101-174, the building admin office. Including any office blocks on Monday to Friday.</p>
            </div>
          </div>

          <div class="d-flex align-items-start gap-4" data-aos="fade-up" data-aos-delay="100">
            <div class="laf-step-num">2</div>
            <div>
              <h6 class="fw-bold mb-1">Bring to Discipline Office</h6>
              <p class="text-muted fs-6 mb-0">Give the found item to attending personnel who will verify and document it appropriately.</p>
            </div>
          </div>

          <div class="d-flex align-items-start gap-4" data-aos="fade-up" data-aos-delay="200">
            <div class="laf-step-num">3</div>
            <div>
              <h6 class="fw-bold mb-1">Office Logging</h6>
              <p class="text-muted fs-6 mb-0">Share collection information for proper record keeping and provide the correct information, even using Campus Lost &amp; Found.</p>
            </div>
          </div>

        </div>
      </div>

    </div>
  </div>
</section>
